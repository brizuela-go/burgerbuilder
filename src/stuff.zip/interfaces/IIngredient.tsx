export interface IIngredient {
  id: string;
  name: string;
  quantity: number;
  icon: string;
}
